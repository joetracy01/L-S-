import React, { useEffect, useState } from 'react';
import '../styles/ticker.css';

interface TickerItem {
  ticker: string;
  price: string;
  change: number;
  position: 'LONG' | 'SHORT';
}

const TICKERS: TickerItem[] = [
  { ticker: 'YAR NO', price: 'NOK 432.7', change: 1.67, position: 'LONG' },
  { ticker: 'BAS GY', price: '€47.80', change: -2.14, position: 'SHORT' },
  { ticker: 'SOLB BB', price: '€27.40', change: -2.33, position: 'SHORT' },
  { ticker: 'DHL GY', price: '€53.20', change: 1.87, position: 'LONG' },
  { ticker: 'VOLVB SS', price: 'SEK 324.6', change: -0.82, position: 'SHORT' },
  { ticker: 'ALTR FP', price: '€14.20', change: -0.99, position: 'SHORT' },
  { ticker: 'ASM NA', price: '€948.00', change: 1.85, position: 'LONG' },
  { ticker: 'BEIERS NA', price: '€118.40', change: 2.14, position: 'LONG' },
  { ticker: 'SOON SW', price: 'CHF 193.9', change: 1.06, position: 'LONG' },
  { ticker: 'GSK LN', price: 'GBp 1983', change: 2.90, position: 'LONG' },
  { ticker: 'SAN FP', price: '€75.07', change: 0.70, position: 'LONG' },
  { ticker: 'BAYN GY', price: '€38.49', change: -2.26, position: 'SHORT' },
];

export default function LiveTicker() {
  const [scrollPosition, setScrollPosition] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setScrollPosition((prev) => (prev + 1) % 100);
    }, 30);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="live-ticker-container">
      <div className="ticker-label">⚡ LIVE UNIVERSE</div>
      <div className="ticker-scroll-wrapper">
        <div 
          className="ticker-scroll"
          style={{
            transform: `translateX(calc(-${scrollPosition}% - ${scrollPosition * 2}px))`,
          }}
        >
          {/* Render tickers twice for seamless loop */}
          {[...TICKERS, ...TICKERS].map((item, idx) => (
            <div key={idx} className={`ticker-item ticker-${item.position.toLowerCase()}`}>
              <span className="ticker-symbol">{item.ticker}</span>
              <span className="ticker-price">{item.price}</span>
              <span className={`ticker-change ${item.change >= 0 ? 'positive' : 'negative'}`}>
                {item.change >= 0 ? '+' : ''}{item.change}%
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
