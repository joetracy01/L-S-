import React, { useState, useEffect, useRef } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import '../styles/dashboard.css';
import '../styles/neural-network.css';
import '../styles/dynamic-weighting.css';
import NeuralNetwork from '../components/NeuralNetwork';
import DynamicWeighting from '../components/DynamicWeighting';

interface StockData {
  ticker: string;
  company: string;
  country: string;
  mktCap: string;
  sector: string;
  position: 'LONG' | 'SHORT';
  weight: 'OW' | 'UW';
  price: string;
  evEbitda: number;
  fcfYield: number;
  fcfDelta: number;
  disruptionVector: string;
  thesis: string;
}

const STOCKS: StockData[] = [
  {
    ticker: 'YAR NO',
    company: 'Yara International',
    country: '🇳🇴',
    mktCap: '€9.2bn',
    sector: 'Chemicals',
    position: 'LONG',
    weight: 'OW',
    price: 'NOK 432.7',
    evEbitda: 5.2,
    fcfYield: 12.4,
    fcfDelta: 380,
    disruptionVector: 'Fertilizer Bottleneck',
    thesis: 'Absolute beneficiary of global nitrogen pricing asymmetry.',
  },
  {
    ticker: 'BAS GY',
    company: 'BASF SE',
    country: '🇩🇪',
    mktCap: '€42.0bn',
    sector: 'Chemicals',
    position: 'SHORT',
    weight: 'UW',
    price: '€47.80',
    evEbitda: 8.5,
    fcfYield: 3.2,
    fcfDelta: -290,
    disruptionVector: 'Oil / Gas Feedstock',
    thesis: 'High European gas inputs & structural margins collapse.',
  },
  {
    ticker: 'SOLB BB',
    company: 'Solvay SA',
    country: '🇧🇪',
    mktCap: '€3.4bn',
    sector: 'Chemicals',
    position: 'SHORT',
    weight: 'UW',
    price: '€27.40',
    evEbitda: 7.1,
    fcfYield: 2.8,
    fcfDelta: -180,
    disruptionVector: 'Oil / Gas Feedstock',
    thesis: 'Energy-intensive essential chemistries highly vulnerable to COGS.',
  },
  {
    ticker: 'DHL GY',
    company: 'DHL Group',
    country: '🇩🇪',
    mktCap: '€44.5bn',
    sector: 'Industrials',
    position: 'LONG',
    weight: 'OW',
    price: '€53.20',
    evEbitda: 6.1,
    fcfYield: 8.9,
    fcfDelta: 180,
    disruptionVector: 'Logistical Shifting',
    thesis: 'Air/Ocean freight rate hardening drives massive margin upside.',
  },
  {
    ticker: 'VOLVB SS',
    company: 'Volvo Group',
    country: '🇸🇪',
    mktCap: '€28.3bn',
    sector: 'Industrials',
    position: 'SHORT',
    weight: 'UW',
    price: 'SEK 324.6',
    evEbitda: 7.8,
    fcfYield: 5.1,
    fcfDelta: -420,
    disruptionVector: 'Aluminium Cost Shock',
    thesis: 'Heavy aluminium exposure; COGS spike crushes truck/construction demand.',
  },
  {
    ticker: 'ALTR FP',
    company: 'Alstom SA',
    country: '🇫🇷',
    mktCap: '€18.2bn',
    sector: 'Industrials',
    position: 'SHORT',
    weight: 'UW',
    price: '€14.20',
    evEbitda: 8.2,
    fcfYield: 1.8,
    fcfDelta: -95,
    disruptionVector: 'Supply Chain Delays',
    thesis: 'Rail/transport infrastructure projects face aluminium supply constraints.',
  },
  {
    ticker: 'ASM NA',
    company: 'ASM International',
    country: '🇳🇱',
    mktCap: '€62.8bn',
    sector: 'Tech/Semis',
    position: 'LONG',
    weight: 'OW',
    price: '€948.00',
    evEbitda: 28.4,
    fcfYield: 3.8,
    fcfDelta: 22,
    disruptionVector: 'None — Structural Insulation',
    thesis: 'Semiconductor equipment demand insulated from Hormuz; structural growth.',
  },
  {
    ticker: 'BEIERS NA',
    company: 'Beiersdorf AG',
    country: '🇩🇪',
    mktCap: '€12.4bn',
    sector: 'Tech/Semis',
    position: 'LONG',
    weight: 'OW',
    price: '€118.40',
    evEbitda: 10.1,
    fcfYield: 5.2,
    fcfDelta: 18,
    disruptionVector: 'None — Defensive Consumer',
    thesis: 'Consumer staples with pricing power; minimal commodity exposure.',
  },
  {
    ticker: 'SOON SW',
    company: 'Sonova Holding',
    country: '🇨🇭',
    mktCap: '€32.5bn',
    sector: 'Tech/Semis',
    position: 'LONG',
    weight: 'OW',
    price: 'CHF 193.9',
    evEbitda: 18.2,
    fcfYield: 4.8,
    fcfDelta: 12,
    disruptionVector: 'None — Demographic Tailwind',
    thesis: 'Hearing aid market insulated; aging demographics drive growth.',
  },
  {
    ticker: 'GSK LN',
    company: 'GSK plc',
    country: '🇬🇧',
    mktCap: '€38.7bn',
    sector: 'Healthcare/Agri',
    position: 'LONG',
    weight: 'OW',
    price: 'GBp 1983',
    evEbitda: 9.4,
    fcfYield: 7.8,
    fcfDelta: 45,
    disruptionVector: 'None — Defensive Pharma',
    thesis: 'Pharmaceutical demand insulated; dividend yield attractive.',
  },
  {
    ticker: 'SAN FP',
    company: 'Sanofi SA',
    country: '🇫🇷',
    mktCap: '€68.4bn',
    sector: 'Healthcare/Agri',
    position: 'LONG',
    weight: 'OW',
    price: '€75.07',
    evEbitda: 10.2,
    fcfYield: 6.4,
    fcfDelta: 38,
    disruptionVector: 'None — Defensive Pharma',
    thesis: 'Large-cap pharma with vaccine exposure; defensive positioning.',
  },
  {
    ticker: 'BAYN GY',
    company: 'Bayer AG',
    country: '🇩🇪',
    mktCap: '€54.2bn',
    sector: 'Healthcare/Agri',
    position: 'SHORT',
    weight: 'UW',
    price: '€38.49',
    evEbitda: 9.8,
    fcfYield: 2.1,
    fcfDelta: -185,
    disruptionVector: 'Fertilizer / Agri Shock',
    thesis: 'Agribusiness division faces fertilizer input cost shock; margin compression.',
  },
];

export default function Dashboard() {
  const [navOpen, setNavOpen] = useState(true);
  const [oilPrice, setOilPrice] = useState(98);
  const [alDeficit, setAlDeficit] = useState(32);
  const [fertMultiplier, setFertMultiplier] = useState(1.45);
  const [selectedStock, setSelectedStock] = useState<StockData | null>(null);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="dashboard-container">
      {/* HEADER */}
      <header className="dashboard-header">
        <div className="header-logo">
          <div className="fund-name">European L/S Equity Alpha Fund</div>
          <div className="fund-sub">Hormuz Stress Dashboard</div>
        </div>
        <div className="header-pills">
          <span className="pill pill-red">⚠ HORMUZ BLOCKADE ACTIVE</span>
          <span className="pill pill-orange">MOU SIGNED 17-JUN-2026</span>
          <span className="pill pill-orange">BRENT $98/bbl</span>
          <span className="pill pill-orange">EU GAS STORAGE 46 BCM</span>
          <span className="pill pill-green">STRESS MODEL LIVE</span>
          <span className="pill pill-orange">CONFIDENTIAL</span>
        </div>
      </header>

      {/* SIDEBAR NAVIGATION */}
      <nav className={`dashboard-nav ${navOpen ? 'open' : 'closed'}`}>
        <button 
          className="nav-toggle"
          onClick={() => setNavOpen(!navOpen)}
        >
          {navOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
        
        {navOpen && (
          <div className="nav-sections">
            <div className="nav-section">
              <h3>📊 EXECUTIVE SUMMARY & MACRO</h3>
              <ul>
                <li><a onClick={() => scrollToSection('macro-framework')}>Macro Framework</a></li>
                <li><a onClick={() => scrollToSection('stress-sliders')}>Stress Sliders</a></li>
                <li><a onClick={() => scrollToSection('heatmap')}>Factor Exposure Heatmap</a></li>
                <li><a onClick={() => scrollToSection('neural-network')}>Crisis Contagion Network</a></li>
              </ul>
            </div>

            <div className="nav-section">
              <h3>🗂 PORTFOLIO MANDATE & BOOK</h3>
              <ul>
                <li><a onClick={() => scrollToSection('master-table')}>Master Portfolio Table</a></li>
              </ul>
            </div>

            <div className="nav-section">
              <h3>🛡 THREE-PILLAR IMPACT MATRIX</h3>
              <ul>
                <li><a onClick={() => scrollToSection('chemicals-cluster')}>🧪 Chemicals Cluster</a></li>
                <li><a onClick={() => scrollToSection('industrials-cluster')}>⚙️ Industrials Cluster</a></li>
                <li><a onClick={() => scrollToSection('tech-cluster')}>💼 Tech / Semis Cluster</a></li>
                <li><a onClick={() => scrollToSection('healthcare-cluster')}>🏥 Healthcare / Agri</a></li>
              </ul>
            </div>

            <div className="nav-section">
              <h3>🔄 PORTFOLIO REALLOCATION</h3>
              <ul>
                <li><a onClick={() => scrollToSection('reallocation')}>Dynamic Weighting Shift</a></li>
              </ul>
            </div>
          </div>
        )}
      </nav>

      {/* MAIN CONTENT */}
      <main className="dashboard-main">
        {/* MACRO FRAMEWORK */}
        <section id="macro-framework" className="section">
          <h2>📊 Macro Framework: The 2026 Hormuz Reality</h2>
          <div className="kpi-grid">
            <div className="kpi-card">
              <div className="kpi-label">Brent Crude (Structural)</div>
              <div className="kpi-value">${oilPrice}</div>
              <div className="kpi-sub">per barrel — structural high</div>
            </div>
            <div className="kpi-card">
              <div className="kpi-label">EU Gas Storage</div>
              <div className="kpi-value">46 bcm</div>
              <div className="kpi-sub">entering spring 2026</div>
            </div>
            <div className="kpi-card">
              <div className="kpi-label">LME Aluminium</div>
              <div className="kpi-value">$3,630</div>
              <div className="kpi-sub">per tonne — 4-year high</div>
            </div>
            <div className="kpi-card">
              <div className="kpi-label">Ammonia / Urea Spike</div>
              <div className="kpi-value">+45%</div>
              <div className="kpi-sub">fertilizer input cost rise</div>
            </div>
            <div className="kpi-card">
              <div className="kpi-label">Blockade Onset</div>
              <div className="kpi-value">28 Feb 2026</div>
              <div className="kpi-sub">IRGC strict blockade declared</div>
            </div>
            <div className="kpi-card">
              <div className="kpi-label">Baseline Normalisation</div>
              <div className="kpi-value">Q1 2027</div>
              <div className="kpi-sub">S&P Global / IEA estimate</div>
            </div>
          </div>
        </section>

        {/* STRESS SLIDERS */}
        <section id="stress-sliders" className="section">
          <h2>⚡ Interactive Stress Vectors — Real-Time Sensitivity Engine</h2>
          <div className="sliders-grid">
            <div className="slider-card">
              <label>🛢 Crude Oil / Feedstock Price</label>
              <input 
                type="range" 
                min="80" 
                max="150" 
                value={oilPrice}
                onChange={(e) => setOilPrice(Number(e.target.value))}
              />
              <div className="slider-value">${oilPrice}/bbl</div>
            </div>
            <div className="slider-card">
              <label>🏗 Aluminium LME Supply Deficit</label>
              <input 
                type="range" 
                min="0" 
                max="60" 
                value={alDeficit}
                onChange={(e) => setAlDeficit(Number(e.target.value))}
              />
              <div className="slider-value">{alDeficit}%</div>
            </div>
            <div className="slider-card">
              <label>🌾 Fertilizer / Ammonia Bottleneck</label>
              <input 
                type="range" 
                min="1" 
                max="2.5" 
                step="0.05"
                value={fertMultiplier}
                onChange={(e) => setFertMultiplier(Number(e.target.value))}
              />
              <div className="slider-value">{fertMultiplier.toFixed(2)}×</div>
            </div>
          </div>
        </section>

        {/* MASTER PORTFOLIO TABLE */}
        <section id="master-table" className="section">
          <h2>🗂 Master Portfolio Table — 12-Stock Universe</h2>
          <div className="table-wrapper">
            <table className="portfolio-table">
              <thead>
                <tr>
                  <th>Ticker</th>
                  <th>Company</th>
                  <th>Country</th>
                  <th>Mkt Cap</th>
                  <th>Sector</th>
                  <th>Position</th>
                  <th>Weight</th>
                  <th>Price</th>
                  <th>EV/EBITDA</th>
                  <th>FCF Yield</th>
                  <th>FCF Δ (bps)</th>
                  <th>Disruption Vector</th>
                  <th>Thesis</th>
                </tr>
              </thead>
              <tbody>
                {STOCKS.map((stock) => (
                  <tr 
                    key={stock.ticker}
                    onClick={() => setSelectedStock(stock)}
                    className="clickable-row"
                  >
                    <td className="ticker">{stock.ticker}</td>
                    <td>{stock.company}</td>
                    <td>{stock.country}</td>
                    <td>{stock.mktCap}</td>
                    <td>{stock.sector}</td>
                    <td className={`position ${stock.position.toLowerCase()}`}>{stock.position}</td>
                    <td className="weight">{stock.weight}</td>
                    <td>{stock.price}</td>
                    <td>{stock.evEbitda}×</td>
                    <td>{stock.fcfYield}%</td>
                    <td className={stock.fcfDelta >= 0 ? 'positive' : 'negative'}>
                      {stock.fcfDelta >= 0 ? '+' : ''}{stock.fcfDelta}
                    </td>
                    <td>{stock.disruptionVector}</td>
                    <td className="thesis">{stock.thesis}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* HEATMAP SECTION */}
        <section id="heatmap" className="section">
          <h2>🔥 Factor Exposure Heatmap — 12-Stock × 3-Vector Sensitivity Matrix</h2>
          <div className="heatmap-container">
            <p>Interactive heatmap visualization showing correlation between stocks and macro stress vectors.</p>
          </div>
        </section>

        {/* NEURAL NETWORK SECTION */}
        <section id="neural-network" className="section">
          <h2>🧠 Crisis Contagion Neural Network — Hormuz Blockade Dependency Graph</h2>
          <NeuralNetwork />
        </section>

        {/* SECTOR CLUSTERS */}
        <section id="chemicals-cluster" className="section">
          <h2>🧪 Chemicals Cluster</h2>
          <div className="cluster-cards">
            {STOCKS.filter(s => s.sector === 'Chemicals').map(stock => (
              <div key={stock.ticker} className="cluster-card" onClick={() => setSelectedStock(stock)}>
                <div className="cluster-ticker">{stock.ticker}</div>
                <div className="cluster-company">{stock.company}</div>
                <div className="cluster-metrics">
                  <div>EV/EBITDA: {stock.evEbitda}×</div>
                  <div>FCF YIELD: {stock.fcfYield}%</div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section id="industrials-cluster" className="section">
          <h2>⚙️ Industrials Cluster</h2>
          <div className="cluster-cards">
            {STOCKS.filter(s => s.sector === 'Industrials').map(stock => (
              <div key={stock.ticker} className="cluster-card" onClick={() => setSelectedStock(stock)}>
                <div className="cluster-ticker">{stock.ticker}</div>
                <div className="cluster-company">{stock.company}</div>
                <div className="cluster-metrics">
                  <div>EV/EBITDA: {stock.evEbitda}×</div>
                  <div>FCF YIELD: {stock.fcfYield}%</div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section id="tech-cluster" className="section">
          <h2>💼 Tech / Semis Cluster</h2>
          <div className="cluster-cards">
            {STOCKS.filter(s => s.sector === 'Tech/Semis').map(stock => (
              <div key={stock.ticker} className="cluster-card" onClick={() => setSelectedStock(stock)}>
                <div className="cluster-ticker">{stock.ticker}</div>
                <div className="cluster-company">{stock.company}</div>
                <div className="cluster-metrics">
                  <div>EV/EBITDA: {stock.evEbitda}×</div>
                  <div>FCF YIELD: {stock.fcfYield}%</div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section id="healthcare-cluster" className="section">
          <h2>🏥 Healthcare / Agri Cluster</h2>
          <div className="cluster-cards">
            {STOCKS.filter(s => s.sector === 'Healthcare/Agri').map(stock => (
              <div key={stock.ticker} className="cluster-card" onClick={() => setSelectedStock(stock)}>
                <div className="cluster-ticker">{stock.ticker}</div>
                <div className="cluster-company">{stock.company}</div>
                <div className="cluster-metrics">
                  <div>EV/EBITDA: {stock.evEbitda}×</div>
                  <div>FCF YIELD: {stock.fcfYield}%</div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* PORTFOLIO REALLOCATION */}
        <section id="reallocation" className="section">
          <h2>🔄 Dynamic Weighting Shift — Base vs. Stress Rebalancing</h2>
          <DynamicWeighting />
        </section>
      </main>

      {/* MODAL */}
      {selectedStock && (
        <div className="modal-overlay" onClick={() => setSelectedStock(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <button className="modal-close" onClick={() => setSelectedStock(null)}>×</button>
            <h2>{selectedStock.ticker} — {selectedStock.company}</h2>
            <div className="modal-metrics">
              <div>EV/EBITDA: {selectedStock.evEbitda}×</div>
              <div>FCF YIELD: {selectedStock.fcfYield}%</div>
              <div>Position: {selectedStock.position}</div>
              <div>Disruption Vector: {selectedStock.disruptionVector}</div>
            </div>
            <p>{selectedStock.thesis}</p>
          </div>
        </div>
      )}
    </div>
  );
}
