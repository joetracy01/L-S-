import React from 'react';
import '../styles/heatmap.css';

interface HeatmapData {
  stock: string;
  oilSensitivity: number;
  alSensitivity: number;
  fertSensitivity: number;
}

const HEATMAP_DATA: HeatmapData[] = [
  { stock: 'YAR NO', oilSensitivity: 15, alSensitivity: 5, fertSensitivity: 95 },
  { stock: 'BAS GY', oilSensitivity: 85, alSensitivity: 20, fertSensitivity: 30 },
  { stock: 'SOLB BB', oilSensitivity: 88, alSensitivity: 15, fertSensitivity: 25 },
  { stock: 'DHL GY', oilSensitivity: 65, alSensitivity: 45, fertSensitivity: 20 },
  { stock: 'VOLVB SS', oilSensitivity: 40, alSensitivity: 75, fertSensitivity: 10 },
  { stock: 'ALTR FP', oilSensitivity: 35, alSensitivity: 55, fertSensitivity: 5 },
  { stock: 'ASM NA', oilSensitivity: 5, alSensitivity: 15, fertSensitivity: 2 },
  { stock: 'BEIERS NA', oilSensitivity: 8, alSensitivity: 12, fertSensitivity: 3 },
  { stock: 'SOON SW', oilSensitivity: 6, alSensitivity: 8, fertSensitivity: 2 },
  { stock: 'GSK LN', oilSensitivity: 10, alSensitivity: 5, fertSensitivity: 8 },
  { stock: 'SAN FP', oilSensitivity: 12, alSensitivity: 4, fertSensitivity: 10 },
  { stock: 'BAYN GY', oilSensitivity: 20, alSensitivity: 18, fertSensitivity: 85 },
];

const getHeatColor = (value: number): string => {
  if (value < 15) return 'heatmap-cold';
  if (value < 35) return 'heatmap-cool';
  if (value < 60) return 'heatmap-warm';
  return 'heatmap-hot';
};

export default function FactorHeatmap() {
  return (
    <div className="heatmap-wrapper">
      <div className="heatmap-title">STRESS IMPACT CORRELATION: COLOUR-CODED BY SENSITIVITY MAGNITUDE</div>
      <div className="heatmap-container">
        <div className="heatmap-header">
          <div className="heatmap-cell header-cell"></div>
          <div className="heatmap-cell header-cell">OIL SENSITIVITY</div>
          <div className="heatmap-cell header-cell">AL SENSITIVITY</div>
          <div className="heatmap-cell header-cell">FERT SENSITIVITY</div>
        </div>
        {HEATMAP_DATA.map((row) => (
          <div key={row.stock} className="heatmap-row">
            <div className="heatmap-cell label-cell">{row.stock}</div>
            <div className={`heatmap-cell ${getHeatColor(row.oilSensitivity)}`}>
              {row.oilSensitivity}%
            </div>
            <div className={`heatmap-cell ${getHeatColor(row.alSensitivity)}`}>
              {row.alSensitivity}%
            </div>
            <div className={`heatmap-cell ${getHeatColor(row.fertSensitivity)}`}>
              {row.fertSensitivity}%
            </div>
          </div>
        ))}
      </div>
      <div className="heatmap-legend">
        <div className="legend-item">
          <span className="legend-color heatmap-cold"></span>
          <span>Low (0-15%)</span>
        </div>
        <div className="legend-item">
          <span className="legend-color heatmap-cool"></span>
          <span>Moderate (15-35%)</span>
        </div>
        <div className="legend-item">
          <span className="legend-color heatmap-warm"></span>
          <span>High (35-60%)</span>
        </div>
        <div className="legend-item">
          <span className="legend-color heatmap-hot"></span>
          <span>Critical (60%+)</span>
        </div>
      </div>
    </div>
  );
}
