import React, { useState } from 'react';
import '../styles/neural-network.css';

interface Node {
  id: string;
  label: string;
  type: 'root' | 'vector' | 'stock';
  x: number;
  y: number;
  color: string;
}

interface Edge {
  from: string;
  to: string;
  strength: number;
}

const NODES: Node[] = [
  // Root shock - center top
  { id: 'hormuz', label: 'HORMUZ\nBLOCKADE', type: 'root', x: 50, y: 12, color: '#C53030' },
  
  // Primary vectors - second row
  { id: 'oil', label: 'OIL', type: 'vector', x: 25, y: 32, color: '#D69E2E' },
  { id: 'al', label: 'ALUMINIUM', type: 'vector', x: 50, y: 32, color: '#D69E2E' },
  { id: 'fert', label: 'FERTILIZER', type: 'vector', x: 75, y: 32, color: '#D69E2E' },
  
  // Secondary stocks - bottom row spread across
  { id: 'YAR', label: 'YAR', type: 'stock', x: 8, y: 65, color: '#2F855A' },
  { id: 'BAS', label: 'BAS', type: 'stock', x: 16, y: 65, color: '#C53030' },
  { id: 'SOLB', label: 'SOLB', type: 'stock', x: 24, y: 65, color: '#C53030' },
  { id: 'DHL', label: 'DHL', type: 'stock', x: 32, y: 65, color: '#2F855A' },
  { id: 'VOLV', label: 'VOLV', type: 'stock', x: 40, y: 65, color: '#C53030' },
  { id: 'ALTR', label: 'ALTR', type: 'stock', x: 48, y: 65, color: '#C53030' },
  { id: 'ASM', label: 'ASM', type: 'stock', x: 56, y: 65, color: '#2F855A' },
  { id: 'BEIERS', label: 'BEIERS', type: 'stock', x: 64, y: 65, color: '#2F855A' },
  { id: 'SOON', label: 'SOON', type: 'stock', x: 72, y: 65, color: '#2F855A' },
  { id: 'GSK', label: 'GSK', type: 'stock', x: 80, y: 65, color: '#2F855A' },
  { id: 'SAN', label: 'SAN', type: 'stock', x: 88, y: 65, color: '#2F855A' },
  { id: 'BAYN', label: 'BAYN', type: 'stock', x: 96, y: 65, color: '#C53030' },
];

const EDGES: Edge[] = [
  // Hormuz to vectors
  { from: 'hormuz', to: 'oil', strength: 1 },
  { from: 'hormuz', to: 'al', strength: 1 },
  { from: 'hormuz', to: 'fert', strength: 1 },
  
  // Oil to stocks
  { from: 'oil', to: 'BAS', strength: 0.9 },
  { from: 'oil', to: 'SOLB', strength: 0.88 },
  { from: 'oil', to: 'DHL', strength: 0.65 },
  { from: 'oil', to: 'VOLV', strength: 0.4 },
  
  // Aluminium to stocks
  { from: 'al', to: 'VOLV', strength: 0.75 },
  { from: 'al', to: 'ALTR', strength: 0.55 },
  { from: 'al', to: 'DHL', strength: 0.45 },
  
  // Fertilizer to stocks
  { from: 'fert', to: 'YAR', strength: 0.95 },
  { from: 'fert', to: 'BAYN', strength: 0.85 },
  { from: 'fert', to: 'SAN', strength: 0.8 },
];

export default function NeuralNetwork() {
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);

  const getNodeClass = (node: Node) => {
    let classes = `network-node node-${node.type}`;
    if (hoveredNode === node.id) classes += ' hovered';
    if (hoveredNode && (EDGES.some(e => e.from === hoveredNode && e.to === node.id) || 
        EDGES.some(e => e.from === node.id && e.to === hoveredNode))) {
      classes += ' connected';
    }
    return classes;
  };

  return (
    <div className="neural-network-wrapper">
      <div className="network-description">
        Following the military escalation and IRGC declaration of Strait closure on 28 February 2026, a three-vector commodity shock propagates through the portfolio. Hormuz blockade → Oil/Aluminium/Fertilizer supply disruption → Portfolio contagion across 12-name universe. Hover over nodes to trace dependency chains.
      </div>
      
      <svg className="network-svg" viewBox="0 0 104 80" preserveAspectRatio="xMidYMid meet">
        {/* Edges */}
        <defs>
          <marker id="arrowhead" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
            <polygon points="0 0, 10 3, 0 6" fill="#8FA3BF" opacity="0.4" />
          </marker>
        </defs>
        
        {EDGES.map((edge, idx) => {
          const fromNode = NODES.find(n => n.id === edge.from);
          const toNode = NODES.find(n => n.id === edge.to);
          if (!fromNode || !toNode) return null;
          
          const isHighlighted = hoveredNode === edge.from || hoveredNode === edge.to;
          const opacity = isHighlighted ? 0.8 : 0.2;
          const strokeWidth = isHighlighted ? 1.2 : 0.6;
          
          return (
            <line
              key={idx}
              x1={fromNode.x}
              y1={fromNode.y}
              x2={toNode.x}
              y2={toNode.y}
              stroke="#8FA3BF"
              strokeWidth={strokeWidth}
              opacity={opacity}
              markerEnd="url(#arrowhead)"
              className="network-edge"
            />
          );
        })}
        
        {/* Nodes */}
        {NODES.map((node) => (
          <g
            key={node.id}
            className={getNodeClass(node)}
            onMouseEnter={() => setHoveredNode(node.id)}
            onMouseLeave={() => setHoveredNode(null)}
          >
            <circle
              cx={node.x}
              cy={node.y}
              r={node.type === 'root' ? 3.5 : node.type === 'vector' ? 3 : 2}
              fill={node.color}
              opacity={hoveredNode === node.id ? 1 : 0.7}
            />
            <text
              x={node.x}
              y={node.y + (node.type === 'root' ? 6 : 4.5)}
              textAnchor="middle"
              className="network-label"
              opacity={hoveredNode === node.id ? 1 : 0.6}
            >
              {node.label}
            </text>
          </g>
        ))}
      </svg>
      
      <div className="network-legend">
        <div className="legend-row">
          <span className="legend-dot root"></span>
          <span>Root Shock</span>
          <span className="legend-dot vector"></span>
          <span>Primary Vector</span>
          <span className="legend-dot long"></span>
          <span>LONG Position</span>
          <span className="legend-dot short"></span>
          <span>SHORT Position</span>
        </div>
      </div>
    </div>
  );
}
