import React from 'react';
import '../styles/dynamic-weighting.css';

interface WeightingData {
  sector: string;
  baseWeight: number;
  stressWeight: number;
  objective: string;
}

const WEIGHTING_DATA: WeightingData[] = [
  {
    sector: 'Chemicals',
    baseWeight: 28,
    stressWeight: 18,
    objective: 'Reduce LONG exposure in Yara (fertilizer spike), maintain SHORT on BASF/Solb (oil feedstock)'
  },
  {
    sector: 'Industrials',
    baseWeight: 24,
    stressWeight: 22,
    objective: 'Trim DHL (logistics exposure), hedge VOLV/ALTR (Aluminium sensitivity)'
  },
  {
    sector: 'Tech/Semis',
    baseWeight: 22,
    stressWeight: 28,
    objective: 'Increase LONG exposure in ASM/Beiers (uncorrelated to Hormuz), hedge supply chain risk'
  },
  {
    sector: 'Healthcare/Agri',
    baseWeight: 26,
    stressWeight: 32,
    objective: 'Increase LONG in GSK/SAN (defensive), maintain SHORT on BAYN (fertilizer input cost risk)'
  },
];

export default function DynamicWeighting() {
  return (
    <div className="dynamic-weighting-wrapper">
      <div className="weighting-description">
        Portfolio reallocation recommendations to maintain factor neutrality as the Hormuz crisis escalates. Base weights reflect pre-crisis positioning; stress weights optimize for crisis-adjusted risk/reward profiles across the four sector clusters.
      </div>

      <div className="weighting-grid">
        {WEIGHTING_DATA.map((item) => (
          <div key={item.sector} className="weighting-card">
            <div className="sector-name">{item.sector}</div>
            
            <div className="weighting-bars">
              <div className="bar-group">
                <div className="bar-label">BASE</div>
                <div className="bar-container">
                  <div 
                    className="bar-fill base" 
                    style={{ width: `${item.baseWeight}%` }}
                  >
                    <span className="bar-value">{item.baseWeight}%</span>
                  </div>
                </div>
              </div>
              
              <div className="bar-group">
                <div className="bar-label">STRESS</div>
                <div className="bar-container">
                  <div 
                    className="bar-fill stress" 
                    style={{ width: `${item.stressWeight}%` }}
                  >
                    <span className="bar-value">{item.stressWeight}%</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="weighting-delta">
              <span className={item.stressWeight > item.baseWeight ? 'positive' : 'negative'}>
                {item.stressWeight > item.baseWeight ? '+' : ''}{item.stressWeight - item.baseWeight}%
              </span>
            </div>

            <div className="objective">{item.objective}</div>
          </div>
        ))}
      </div>

      <div className="weighting-summary">
        <div className="summary-item">
          <span className="label">GROSS EXPOSURE:</span>
          <span className="value">100% Base → 100% Stress (Neutral)</span>
        </div>
        <div className="summary-item">
          <span className="label">NET EXPOSURE:</span>
          <span className="value">Maintain LONG bias while hedging Hormuz-specific contagion</span>
        </div>
        <div className="summary-item">
          <span className="label">REBALANCE FREQUENCY:</span>
          <span className="value">Daily (or on significant Brent/LME moves)</span>
        </div>
      </div>
    </div>
  );
}
