# Strait of Hormuz Stress Test Briefing Notes

## Document metadata
- Title: **European L/S Equity Alpha Fund**
- Subtitle: Portfolio Management Directive & Real-Time Stress Testing
- Date: **June 26, 2026**
- Subject: **Strait of Hormuz Crisis: Structural Realignment**

## Macro framework
- Military escalation began **February 28, 2026**.
- A strict blockade by the IRGC choked transit through the Strait of Hormuz.
- Although a **June 17, 2026** memorandum of understanding was signed between Washington and Tehran, S&P Global and the IEA indicate that a return to pre-conflict commercial shipping baseline is not expected before **Q1 2027**.
- Brent crude peaked at **$126/bbl** in March and remains near **$98/bbl**.
- European natural gas storage fell to **46 bcm** entering spring versus **60 bcm in 2025**.
- Three core disruption vectors named in the document:
  1. **Crude/Gas Spikes**
  2. **Aluminium Deficit**
  3. **Ammonia/Phosphate bottlenecks**

## Portfolio mandate
- European equities only.
- Market-cap range constrained to **€1bn–€200bn**.

## 12-stock universe from the briefing
| Ticker | Company | Country | Market Cap | Sector | Position | Core thesis |
|---|---|---:|---:|---|---|---|
| YAR NO | Yara International | Norway | ~€9.2bn | Chemicals | Long | Benefits from global nitrogen pricing asymmetry |
| BAS GY | BASF SE | Germany | ~€42.0bn | Chemicals | Short | High European gas inputs and structural margin collapse |
| SOLB BB | Solvay SA | Belgium | ~€3.4bn | Chemicals | Short | Energy-intensive essential chemistries vulnerable to COGS |
| DHL GY | DHL Group | Germany | ~€44.5bn | Industrials | Long | Air/ocean freight rate hardening supports margins |
| VOLVB SS | Volvo Group | Sweden | ~€48.2bn | Industrials | Short | Aluminium-driven margin compression |
| ALTR FP | Alstom SA | France | ~€6.8bn | Industrials | Short | Delivery delays and contract penalties via long lead components |
| ASM NA | ASM International | Netherlands | ~€29.8bn | Tech / Semis | Long | Structurally insulated from primary energy shocks |
| BEIERS NA | Beiersdorf AG | Germany | ~€12.2bn | Consumer / Tech | Long | Replaced ASML due to market-cap constraints; robust defensive cash |
| SOON SW | Sonova Holding | Switzerland | ~€14.1bn | Tech / Semis | Long | Specialty medical tech insulated from Hormuz cargo channels |
| GSK LN | GSK plc | UK | ~€77.9bn | Healthcare | Long | High FCF yield buffer protects against sell-offs |
| SAN FP | Sanofi SA | France | ~€89.0bn | Healthcare | Long | Strong defensive cash profile; localized supply |
| BAYN GY | Bayer AG | Germany | ~€37.2bn | Healthcare / Ag | Short | CropScience exposed to input-cost inflation |

## Detailed stress-testing metrics explicitly stated in the PDF
### Yara International (Long)
- Natural gas input cost rises assumed at **45%**.
- EV/EBITDA contracts from **4.8x** to **4.4x**.
- FCF yield modeled to expand to **12.4%**.

### BASF SE (Short)
- EPS forecasts cut by **22%** for FY26.
- EV/EBITDA target / stress level shown in matrix: **8.5x**.
- Impact on FCF yield in matrix: **-290 bps**.

### DHL Group (Long)
- Revenue modeled to rise **+14% YoY**.
- FCF yield in matrix: **8.9%**.
- EV/EBITDA target / stress level in matrix: **6.1x**.
- Impact on FCF yield in matrix: **+180 bps**.

### Volvo Group (Short)
- LME spot prices up **32%**.
- COGS expands by **420 bps** in truck assembly segment.
- EBITDA margins contract from **11.5%** to **8.2%**.
- EV/EBITDA target / stress level in matrix: **7.8x**.
- Impact on FCF yield in matrix: **-210 bps**.

### ASM International (Long)
- Secondary-order energy exposure estimated at less than **3.5%** of operational expenditure.

### Bayer AG (Short)
- FCF yield remains constrained due to structural liabilities.
- EV/EBITDA target / stress level in matrix: **9.8x**.
- Impact on FCF yield in matrix: **-140 bps**.

### Sanofi SA (Long)
- EV/EBITDA target / stress level in matrix: **10.2x**.
- Impact on FCF yield in matrix: **Stable**.

### Tactical pair expression explicitly stated
- **Long Yara International (YAR NO)** vs **Short BASF SE (BAS GY)**.
- Rationale: Capture pure-play fertilizer pricing power versus catastrophic structural margin compression from feedstock gas spikes.

## Alpha capture / execution matrix from page 4
| Ticker | Weight bias | Primary disruption vector | Target EV/EBITDA Stress | Expected impact on FCF yield | Alpha capture mechanism |
|---|---|---|---:|---|---|
| YAR NO | Overweight | Fertilizer Bottleneck | 5.2x | +380 bps | Long captures global nitrogen pricing power |
| BAS GY | Underweight | Oil / Gas Feedstock | 8.5x | -290 bps | Short captures structural margin compression |
| DHL GY | Overweight | Logistical Shifting | 6.1x | +180 bps | Long captures global freight-rate hardening |
| VOLVB SS | Underweight | Aluminium Deficit | 7.8x | -210 bps | Short exploits mispriced automotive inputs |
| SAN FP | Overweight | Unaffected / Defensive | 10.2x | Stable | Defensive cash-yield buffer |
| BAYN GY | Underweight | Agribusiness Shock | 9.8x | -140 bps | Short exposes secondary agricultural risks |

## Risk mitigation and execution guardrails
1. **MOU violations risk:** If the June 17 agreement breaks down and military actions resume, short positions in **VOLVB SS** and **BAS GY** may need to be maximized because aluminium and oil vectors would face vertical price shocks.
2. **Factor neutrality:** Shorts in industrials are paired with longs in logistics (**DHL GY**) and structural tech (**ASM NA**) to avoid naked short exposure to European manufacturing.

## Source references explicitly named in the PDF
- **S&P Global**
- **IEA energy balance models / balance grids**
- **LME warehouse stock tracking**
- **Strait of Hormuz Blockade and Fleet Tracking Analysis (2026)**

## Dashboard implementation implications
- Use slider baselines from the user prompt, not from the PDF alone:
  - Crude oil baseline **$98** with stress range **$80–$150**
  - Aluminium LME deficit baseline **32%** with stress range **0%–60%**
  - Fertilizer/ammonia bottleneck multiplier baseline **1.45x** with stress range **1.0x–2.5x**
- Need to create real-time updating metrics and color inversion logic depending on **Long vs Short** positions.
- Need ticker prices for all 12 companies and citation anchors for every sector block / data window.
- Need modal drill-down content for first- and second-order dependencies, maritime fleet linkages, and localized facility energy exposures for all 12 companies.
- Need responsive single-page dashboard with sticky left navigation and top-right live ticker marquee.

## Gaps still requiring research
- Current share prices / ticker display values for all 12 names.
- Detailed dependencies and facility exposures for companies not deeply covered in the PDF (Solvay, Alstom, Beiersdorf, Sonova, GSK, and possibly Sanofi).
- Citation URLs or publication references to support the footer disclosure and sector annotations.
- Cohesive data model for stress update formulas across all 12 names.
